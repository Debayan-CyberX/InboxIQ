// Express server for Better Auth API routes
// Run this server alongside your Vite dev server
import dotenv from "dotenv";
import express, { Request as ExpressRequest, Response as ExpressResponse } from "express";
import cors from "cors";
import { auth } from "./auth.js";

// Load .env.local file (dotenv by default loads .env, but we want .env.local)
dotenv.config({ path: ".env.local" });
dotenv.config(); // Also load .env if it exists (lower priority)

const app = express();
const PORT = process.env.AUTH_PORT || 3001;
const VITE_PORT = process.env.VITE_PORT || 8080;

// Middleware - Allow all localhost origins for development
app.use(cors({
  origin: [
    "http://localhost:8080",
    "http://localhost:8081", // Your Vite port
    "http://localhost:5173",
    "http://127.0.0.1:8080",
    "http://127.0.0.1:8081",
    "http://127.0.0.1:5173",
    `http://localhost:${VITE_PORT}`,
    process.env.VITE_APP_URL || "http://localhost:8080"
  ],
  credentials: true,
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization", "Cookie"],
}));
app.use(express.json());

// Convert Express request to Web API Request for Better Auth
async function expressToWebRequest(req: ExpressRequest): Promise<Request> {
  const protocol = req.protocol || 'http';
  const host = req.get('host') || 'localhost:3001';
  const url = `${protocol}://${host}${req.originalUrl}`;
  
  const headers = new Headers();
  Object.keys(req.headers).forEach(key => {
    const value = req.headers[key];
    if (value) {
      headers.set(key, Array.isArray(value) ? value.join(', ') : value);
    }
  });

  let body: string | undefined;
  if (req.method !== 'GET' && req.method !== 'HEAD' && req.body) {
    body = JSON.stringify(req.body);
    headers.set('Content-Type', 'application/json');
  }

  const init: RequestInit = {
    method: req.method,
    headers: headers,
    body: body,
  };
  
  return new Request(url, init);
}

// Convert Web API Response to Express response
async function webToExpressResponse(webResponse: Response, expressRes: ExpressResponse) {
  expressRes.status(webResponse.status);
  webResponse.headers.forEach((value, key) => {
    expressRes.setHeader(key, value);
  });
  const body = await webResponse.text();
  expressRes.send(body);
}

// Better Auth API routes
// Use app.use() to catch all routes starting with /api/auth
app.use("/api/auth", async (req: ExpressRequest, res: ExpressResponse) => {
  try {
    console.log(`📥 ${req.method} ${req.originalUrl}`);
    console.log(`   Origin: ${req.get('origin') || 'none'}`);
    
    // Convert Express request to Web API Request
    const webRequest = await expressToWebRequest(req);
    
    // Call Better Auth handler
    const webResponse = await auth.handler(webRequest);
    
    // Log response status
    console.log(`   Response: ${webResponse.status} ${webResponse.statusText}`);
    
    // Log response body for debugging
    const responseClone = webResponse.clone();
    const responseText = await responseClone.text();
    if (responseText) {
      try {
        const responseJson = JSON.parse(responseText);
        console.log(`   Response body:`, JSON.stringify(responseJson, null, 2));
        if (responseJson.error) {
          console.error(`   ❌ Error:`, responseJson.error);
        }
      } catch {
        console.log(`   Response body (text):`, responseText.substring(0, 200));
      }
    }
    
    // Convert Web API Response back to Express response
    await webToExpressResponse(webResponse, res);
  } catch (error) {
    console.error("❌ Auth handler error:", error);
    console.error("   Error type:", error?.constructor?.name);
    console.error("   Message:", error instanceof Error ? error.message : String(error));
    if (error instanceof Error && error.stack) {
      console.error("   Stack:", error.stack);
    }
    if (!res.headersSent) {
      res.status(500).json({ 
        error: "Internal server error", 
        message: error instanceof Error ? error.message : String(error),
        type: error?.constructor?.name || "Unknown"
      });
    }
  }
});

// Health check
app.get("/health", (req, res) => {
  res.json({ status: "ok", service: "better-auth" });
});

// Test endpoint to verify CORS and connection
app.get("/api/test", (req, res) => {
  res.json({ 
    status: "ok", 
    message: "Auth server is reachable",
    origin: req.get('origin') || 'none',
    timestamp: new Date().toISOString()
  });
});

app.listen(PORT, () => {
  console.log(`\n✅ Better Auth server running on http://localhost:${PORT}`);
  console.log(`📡 Auth API available at http://localhost:${PORT}/api/auth`);
  console.log(`🔗 Make sure VITE_BETTER_AUTH_URL=http://localhost:${PORT} in your .env.local\n`);
});
