import { useState } from "react";
import { Bell, Search, Calendar, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import ConnectEmailDialog from "@/components/ConnectEmailDialog";

const Header = () => {
  const [isConnectDialogOpen, setIsConnectDialogOpen] = useState(false);
  const [isEmailConnected, setIsEmailConnected] = useState(false);
  const [connectedEmail, setConnectedEmail] = useState<string | null>(null);

  const today = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    month: 'short', 
    day: 'numeric' 
  });

  const handleEmailConnected = () => {
    setIsEmailConnected(true);
    // In production, you'd get this from the OAuth callback or API
    setConnectedEmail("user@example.com");
  };

  return (
    <>
      <header className="h-16 border-b border-border bg-card/80 backdrop-blur-xl flex items-center justify-between px-6">
        <div className="flex items-center gap-4">
          <div>
            <h1 className="text-xl font-semibold text-foreground">Good morning, <span className="text-gradient">Debayan</span></h1>
            <p className="text-sm text-muted-foreground flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" />
              {today}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search leads, emails..."
              className="w-64 h-9 pl-9 pr-4 rounded-lg bg-secondary/50 border border-border text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:bg-background transition-all"
            />
          </div>

          {/* Notifications */}
          <Button variant="ghost" size="icon-sm" className="relative">
            <Bell className="w-4 h-4" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-status-hot" />
          </Button>

          {/* Connect Email CTA */}
          {isEmailConnected ? (
            <Button 
              variant="outline" 
              size="sm"
              className="gap-2"
              onClick={() => setIsConnectDialogOpen(true)}
            >
              <CheckCircle2 className="w-4 h-4 text-green-400" />
              <span className="hidden sm:inline">Connected</span>
            </Button>
          ) : (
            <Button 
              variant="accent" 
              size="sm"
              onClick={() => setIsConnectDialogOpen(true)}
            >
              Connect Email
            </Button>
          )}
        </div>
      </header>

      <ConnectEmailDialog
        open={isConnectDialogOpen}
        onOpenChange={setIsConnectDialogOpen}
        onConnected={handleEmailConnected}
      />
    </>
  );
};

export default Header;
