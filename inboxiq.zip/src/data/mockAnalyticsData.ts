// Mock analytics data for Analytics page

export interface TimeSeriesData {
  date: string;
  value: number;
  label?: string;
}

export interface MetricTrend {
  current: number;
  previous: number;
  change: number;
  trend: "up" | "down" | "neutral";
}

export interface LeadStatusDistribution {
  hot: number;
  warm: number;
  cold: number;
}

export interface EmailPerformance {
  sent: number;
  replied: number;
  opened: number;
  clicked: number;
}

export const mockAnalytics = {
  // Overview metrics
  overview: {
    totalLeads: { current: 124, previous: 98, change: 26.5, trend: "up" as const },
    activeConversations: { current: 48, previous: 42, change: 14.3, trend: "up" as const },
    replyRate: { current: 68, previous: 56, change: 21.4, trend: "up" as const },
    avgResponseTime: { current: 2.4, previous: 3.8, change: -36.8, trend: "up" as const }, // Negative change is good for response time
    timeSaved: { current: 24.5, previous: 18.2, change: 34.6, trend: "up" as const },
    aiDraftsUsed: { current: 156, previous: 112, change: 39.3, trend: "up" as const },
  },

  // Lead status distribution
  leadDistribution: {
    hot: 28,
    warm: 45,
    cold: 51,
  },

  // Email performance over time (last 7 days)
  emailPerformance: [
    { date: "Mon", sent: 12, replied: 8, opened: 10, clicked: 5 },
    { date: "Tue", sent: 15, replied: 11, opened: 13, clicked: 7 },
    { date: "Wed", sent: 18, replied: 13, opened: 16, clicked: 9 },
    { date: "Thu", sent: 14, replied: 10, opened: 12, clicked: 6 },
    { date: "Fri", sent: 20, replied: 15, opened: 18, clicked: 11 },
    { date: "Sat", sent: 8, replied: 5, opened: 7, clicked: 3 },
    { date: "Sun", sent: 10, replied: 7, opened: 9, clicked: 4 },
  ],

  // Reply rate over time (last 30 days)
  replyRateTrend: [
    { date: "Week 1", value: 52 },
    { date: "Week 2", value: 58 },
    { date: "Week 3", value: 64 },
    { date: "Week 4", value: 68 },
  ],

  // Response time trend (hours)
  responseTimeTrend: [
    { date: "Week 1", value: 4.2 },
    { date: "Week 2", value: 3.6 },
    { date: "Week 3", value: 3.1 },
    { date: "Week 4", value: 2.4 },
  ],

  // AI usage stats
  aiUsage: {
    draftsGenerated: 156,
    draftsSent: 128,
    adoptionRate: 82,
    avgConfidence: 89,
    timeSaved: 24.5,
  },

  // Top performing leads
  topLeads: [
    { company: "Acme Corporation", replies: 12, status: "hot" as const, value: 45000 },
    { company: "TechStart Inc", replies: 9, status: "hot" as const, value: 32000 },
    { company: "Global Dynamics", replies: 7, status: "warm" as const, value: 28000 },
    { company: "Velocity Partners", replies: 6, status: "warm" as const, value: 22000 },
    { company: "InnovateTech", replies: 5, status: "hot" as const, value: 18000 },
  ],

  // Email activity by day of week
  activityByDay: [
    { day: "Monday", emails: 45, replies: 32 },
    { day: "Tuesday", emails: 52, replies: 38 },
    { day: "Wednesday", emails: 48, replies: 35 },
    { day: "Thursday", emails: 41, replies: 29 },
    { day: "Friday", emails: 38, replies: 27 },
    { day: "Saturday", emails: 15, replies: 10 },
    { day: "Sunday", emails: 12, replies: 8 },
  ],

  // Conversion funnel
  conversionFunnel: {
    leads: 124,
    contacted: 98,
    replied: 67,
    meetings: 23,
    closed: 8,
  },
};

