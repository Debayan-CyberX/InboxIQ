// Mock data for InboxIQ dashboard

export const mockLeads = [
  {
    id: "1",
    company: "Acme Corporation",
    contact: "Sarah Chen",
    email: "sarah@acme.co",
    lastMessage: "We're very interested in your enterprise plan. Can you share pricing details and implementation timeline?",
    daysSinceContact: 1,
    status: "hot" as const,
    aiSuggestion: "Send pricing proposal",
    hasAIDraft: true,
  },
  {
    id: "2",
    company: "TechStart Inc",
    contact: "Michael Roberts",
    email: "michael@techstart.io",
    lastMessage: "Thanks for the demo yesterday! The team was impressed. Let's schedule a follow-up.",
    daysSinceContact: 2,
    status: "hot" as const,
    aiSuggestion: "Propose meeting slots",
    hasAIDraft: true,
  },
  {
    id: "3",
    company: "Global Dynamics",
    contact: "Jennifer Walsh",
    email: "jwalsh@globaldynamics.com",
    lastMessage: "I'll need to discuss this with our procurement team. They'll be back next week.",
    daysSinceContact: 5,
    status: "warm" as const,
    aiSuggestion: "Follow up — deal at risk",
    hasAIDraft: false,
  },
  {
    id: "4",
    company: "Velocity Partners",
    contact: "David Kim",
    email: "d.kim@velocity.partners",
    lastMessage: "Interesting solution. We're evaluating a few options right now.",
    daysSinceContact: 3,
    status: "warm" as const,
    aiSuggestion: "Share case study",
    hasAIDraft: true,
  },
  {
    id: "5",
    company: "Nexus Solutions",
    contact: "Amanda Foster",
    email: "amanda.f@nexussolutions.com",
    lastMessage: "We might revisit this in Q2 when our budget cycle resets.",
    daysSinceContact: 8,
    status: "cold" as const,
    hasAIDraft: false,
  },
  {
    id: "6",
    company: "Bright Future Co",
    contact: "Chris Martinez",
    email: "chris@brightfuture.co",
    lastMessage: "Not a priority for us at the moment, but keep us posted.",
    daysSinceContact: 12,
    status: "cold" as const,
    hasAIDraft: false,
  },
];

export const mockActions = [
  {
    id: "1",
    type: "reply" as const,
    company: "Acme Corporation",
    subject: "Send pricing proposal with enterprise tier details",
    reason: "Hot lead asked for pricing 1 day ago",
    priority: "high" as const,
    hasAIDraft: true,
  },
  {
    id: "2",
    type: "follow-up" as const,
    company: "Global Dynamics",
    subject: "Check in on procurement team discussion",
    reason: "No reply in 5 days — deal at risk",
    priority: "high" as const,
    hasAIDraft: true,
  },
  {
    id: "3",
    type: "meeting" as const,
    company: "TechStart Inc",
    subject: "Propose follow-up meeting with decision makers",
    reason: "Positive demo feedback, momentum building",
    priority: "medium" as const,
    hasAIDraft: true,
  },
  {
    id: "4",
    type: "follow-up" as const,
    company: "Velocity Partners",
    subject: "Share relevant case study to differentiate",
    reason: "They're evaluating competitors",
    priority: "medium" as const,
    hasAIDraft: true,
  },
];

export const mockInsight = {
  text: "You have 3 hot leads requiring attention today. Acme Corporation is ready for a pricing proposal — they've shown strong buying signals. Global Dynamics has gone quiet for 5 days and may need a gentle nudge before the deal cools. TechStart Inc is building momentum after yesterday's demo.",
  highlights: [
    { type: "hot" as const, text: "3 hot leads need replies" },
    { type: "risk" as const, text: "1 deal at risk" },
    { type: "opportunity" as const, text: "2 ready for proposals" },
  ],
};

export const mockPerformanceMetrics = [
  {
    label: "Reply Rate",
    value: "68%",
    change: { value: 12, trend: "up" as const },
    icon: null,
  },
  {
    label: "Avg Response",
    value: "2.4h",
    change: { value: 18, trend: "up" as const },
    icon: null,
  },
  {
    label: "Time Saved",
    value: "4.2h",
    change: { value: 0, trend: "neutral" as const },
    icon: null,
  },
];

export const mockEmailDraft = {
  to: "sarah@acme.co",
  subject: "Re: Enterprise Plan Pricing & Implementation",
  company: "Acme Corporation",
  reason: "Sarah asked for pricing details. This is a high-intent buying signal from a qualified lead.",
  draft: `Hi Sarah,

Thank you for your interest in our enterprise plan! I'm excited to help you move forward.

Based on your team size and requirements, here's what I recommend:

**Enterprise Plan — $299/seat/month**
• Unlimited email tracking & AI assistance
• Priority support with dedicated success manager
• Custom integrations & API access
• Advanced analytics & reporting

**Implementation Timeline:**
• Week 1: Account setup & team onboarding
• Week 2: Custom workflow configuration
• Week 3: Full rollout with ongoing support

I'd love to schedule a quick call to walk through these details and answer any questions your team might have.

Would Thursday at 2pm or Friday at 10am work for you?

Best,
John`,
};
