// Mock draft data for Drafts page

export interface EmailDraft {
  id: string;
  to: string;
  toName: string;
  company: string;
  subject: string;
  draft: string;
  reason: string;
  tone: "professional" | "short" | "confident" | "polite" | "sales-focused";
  confidence: number; // 0-100
  createdAt: string;
  leadId?: string;
  threadId?: string;
  status: "draft" | "reviewed" | "sent" | "archived";
  priority: "high" | "medium" | "low";
  tags?: string[];
}

export const mockDrafts: EmailDraft[] = [
  {
    id: "1",
    to: "sarah@acme.co",
    toName: "Sarah Chen",
    company: "Acme Corporation",
    subject: "Re: Enterprise Plan Pricing & Implementation",
    draft: `Hi Sarah,

Thank you for your interest in our enterprise plan! I'm excited to help you move forward.

Based on your team size and requirements, here's what I recommend:

**Enterprise Plan — $299/seat/month**
• Unlimited email tracking & AI assistance
• Priority support with dedicated success manager
• Custom integrations & API access
• Advanced analytics & reporting

**Implementation Timeline:**
• Week 1: Account setup & team onboarding
• Week 2: Custom workflow configuration
• Week 3: Full rollout with ongoing support

I'd love to schedule a quick call to walk through these details and answer any questions your team might have.

Would Thursday at 2pm or Friday at 10am work for you?

Best,
John`,
    reason: "Sarah asked for pricing details. This is a high-intent buying signal from a qualified lead.",
    tone: "professional",
    confidence: 95,
    createdAt: "2 hours ago",
    leadId: "1",
    status: "draft",
    priority: "high",
    tags: ["Hot Lead", "Pricing"],
  },
  {
    id: "2",
    to: "michael@techstart.io",
    toName: "Michael Roberts",
    company: "TechStart Inc",
    subject: "Re: Follow-up Meeting - Next Steps",
    draft: `Hi Michael,

Great to hear the team was impressed with yesterday's demo! I'm excited to help you move forward.

Based on our discussion, I'd like to propose a few meeting slots for our follow-up:

**Available Times:**
• Tuesday, Jan 9th at 2:00 PM EST
• Wednesday, Jan 10th at 10:00 AM EST
• Thursday, Jan 11th at 3:00 PM EST

During this call, we can:
- Discuss your specific use cases in detail
- Walk through custom integration options
- Address any questions from your team
- Outline a tailored implementation plan

Let me know which time works best for you, or if you'd prefer a different slot.

Looking forward to continuing the conversation!

Best regards,
John`,
    reason: "Positive demo feedback received. Momentum is building - propose meeting to close the deal.",
    tone: "confident",
    confidence: 92,
    createdAt: "5 hours ago",
    leadId: "2",
    status: "draft",
    priority: "high",
    tags: ["Demo", "Meeting"],
  },
  {
    id: "3",
    to: "jwalsh@globaldynamics.com",
    toName: "Jennifer Walsh",
    company: "Global Dynamics",
    subject: "Re: Procurement Team Discussion - Follow-up",
    draft: `Hi Jennifer,

I wanted to follow up on our conversation about the procurement team discussion. I know you mentioned they'd be back next week.

I've prepared a quick summary document that might be helpful for your internal discussions:
- Pricing breakdown by tier
- Implementation timeline
- ROI projections based on your use case
- Security & compliance details

Would it be helpful if I scheduled a brief call with your procurement team once they're back? I'm happy to answer any questions they might have.

Let me know what works best for your timeline.

Best,
John`,
    reason: "No reply in 5 days - deal at risk. Gentle follow-up to re-engage before it goes cold.",
    tone: "polite",
    confidence: 88,
    createdAt: "1 day ago",
    leadId: "3",
    status: "draft",
    priority: "high",
    tags: ["At Risk", "Follow-up"],
  },
  {
    id: "4",
    to: "d.kim@velocity.partners",
    toName: "David Kim",
    company: "Velocity Partners",
    subject: "Re: Case Study Request - Similar Use Case",
    draft: `Hi David,

Thanks for your interest! I'd be happy to share a case study that's very relevant to your situation.

**Case Study: TechCorp's Success Story**
- Similar industry and company size
- Implemented in 3 weeks
- 40% increase in lead response rate
- 3x faster follow-up times

I've attached the full case study document. The key highlights:
- How they integrated with their existing CRM
- ROI achieved in first quarter
- Team adoption and feedback

I'd also be happy to connect you with their team for a reference call if that would be helpful.

Let me know if you have any questions!

Best,
John`,
    reason: "They're evaluating competitors. Share case study to differentiate and build trust.",
    tone: "sales-focused",
    confidence: 90,
    createdAt: "2 days ago",
    leadId: "4",
    status: "draft",
    priority: "medium",
    tags: ["Case Study", "Evaluation"],
  },
  {
    id: "5",
    to: "mchen@innovate.tech",
    toName: "Michael Chen",
    company: "InnovateTech",
    subject: "Re: Integration Questions - Technical Call",
    draft: `Hi Michael,

Great questions about API integration and custom workflows! I'd love to schedule a technical call to address these in detail.

**What we'll cover:**
- API documentation and endpoints
- Custom workflow configuration options
- Integration with your existing tools
- Webhook setup for real-time updates
- Authentication and security best practices

**Available slots:**
• Tomorrow at 2:00 PM EST
• Thursday at 11:00 AM EST
• Friday at 3:00 PM EST

I'll also send over our technical documentation ahead of time so you can review it beforehand.

Looking forward to the call!

Best,
John`,
    reason: "Technical questions about integration. Schedule call to provide detailed answers and move deal forward.",
    tone: "professional",
    confidence: 93,
    createdAt: "3 hours ago",
    status: "draft",
    priority: "medium",
    tags: ["Technical", "Integration"],
  },
];

