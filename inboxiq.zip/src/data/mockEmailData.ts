// Mock email data for Inbox page

export interface EmailThread {
  id: string;
  subject: string;
  from: {
    name: string;
    email: string;
    avatar?: string;
  };
  company?: string;
  leadId?: string;
  preview: string;
  timestamp: string;
  isRead: boolean;
  isImportant: boolean;
  isStarred: boolean;
  hasAttachment: boolean;
  unreadCount: number;
  emailCount: number;
  lastActivity: string;
  status: "active" | "archived" | "closed";
  tags?: string[];
  aiSuggestion?: string;
  hasAIDraft?: boolean;
}

export const mockEmailThreads: EmailThread[] = [
  {
    id: "1",
    subject: "Partnership Opportunity - Q1 2024",
    from: {
      name: "John Davis",
      email: "john.davis@techcorp.com",
    },
    company: "TechCorp Inc",
    leadId: "1",
    preview: "We're very interested in your enterprise plan. Can you share pricing details and implementation timeline?",
    timestamp: "2 hours ago",
    isRead: false,
    isImportant: true,
    isStarred: true,
    hasAttachment: false,
    unreadCount: 1,
    emailCount: 3,
    lastActivity: "2 hours ago",
    status: "active",
    tags: ["Hot Lead", "Enterprise"],
    aiSuggestion: "Send pricing proposal",
    hasAIDraft: true,
  },
  {
    id: "2",
    subject: "Re: Product Demo Request",
    from: {
      name: "Sarah Martinez",
      email: "sarah@growthlabs.io",
    },
    company: "Growth Labs",
    leadId: "2",
    preview: "Thanks for the demo yesterday! The team was impressed. Let's schedule a follow-up meeting.",
    timestamp: "5 hours ago",
    isRead: true,
    isImportant: true,
    isStarred: false,
    hasAttachment: true,
    unreadCount: 0,
    emailCount: 5,
    lastActivity: "5 hours ago",
    status: "active",
    tags: ["Demo", "Follow-up"],
    aiSuggestion: "Propose meeting slots",
    hasAIDraft: true,
  },
  {
    id: "3",
    subject: "Pricing Inquiry - Enterprise Plan",
    from: {
      name: "Alex Lee",
      email: "alex@startuphub.com",
    },
    company: "StartupHub",
    leadId: "3",
    preview: "No response in 3 days - lead may go cold soon. Should we send a follow-up?",
    timestamp: "1 day ago",
    isRead: false,
    isImportant: false,
    isStarred: false,
    hasAttachment: false,
    unreadCount: 1,
    emailCount: 2,
    lastActivity: "3 days ago",
    status: "active",
    tags: ["At Risk"],
    aiSuggestion: "Follow up - deal at risk",
    hasAIDraft: false,
  },
  {
    id: "4",
    subject: "Re: Implementation Timeline",
    from: {
      name: "Jennifer Walsh",
      email: "jwalsh@globaldynamics.com",
    },
    company: "Global Dynamics",
    leadId: "4",
    preview: "I'll need to discuss this with our procurement team. They'll be back next week.",
    timestamp: "2 days ago",
    isRead: true,
    isImportant: false,
    isStarred: false,
    hasAttachment: false,
    unreadCount: 0,
    emailCount: 4,
    lastActivity: "2 days ago",
    status: "active",
    tags: ["Warm"],
    aiSuggestion: "Check in on procurement team discussion",
    hasAIDraft: true,
  },
  {
    id: "5",
    subject: "Case Study Request",
    from: {
      name: "David Kim",
      email: "d.kim@velocity.partners",
    },
    company: "Velocity Partners",
    leadId: "5",
    preview: "Interesting solution. We're evaluating a few options right now. Can you share a case study?",
    timestamp: "3 days ago",
    isRead: true,
    isImportant: false,
    isStarred: false,
    hasAttachment: false,
    unreadCount: 0,
    emailCount: 3,
    lastActivity: "3 days ago",
    status: "active",
    tags: ["Evaluation"],
    aiSuggestion: "Share case study",
    hasAIDraft: true,
  },
  {
    id: "6",
    subject: "Q2 Budget Discussion",
    from: {
      name: "Amanda Foster",
      email: "amanda.f@nexussolutions.com",
    },
    company: "Nexus Solutions",
    leadId: "6",
    preview: "We might revisit this in Q2 when our budget cycle resets. Keep us posted on any updates.",
    timestamp: "5 days ago",
    isRead: true,
    isImportant: false,
    isStarred: false,
    hasAttachment: false,
    unreadCount: 0,
    emailCount: 2,
    lastActivity: "5 days ago",
    status: "active",
    tags: ["Cold", "Q2"],
    hasAIDraft: false,
  },
  {
    id: "7",
    subject: "Thank You - Product Launch",
    from: {
      name: "Chris Martinez",
      email: "chris@brightfuture.co",
    },
    company: "Bright Future Co",
    leadId: "7",
    preview: "Not a priority for us at the moment, but keep us posted on future developments.",
    timestamp: "1 week ago",
    isRead: true,
    isImportant: false,
    isStarred: false,
    hasAttachment: false,
    unreadCount: 0,
    emailCount: 1,
    lastActivity: "1 week ago",
    status: "archived",
    hasAIDraft: false,
  },
  {
    id: "8",
    subject: "Integration Questions",
    from: {
      name: "Michael Chen",
      email: "mchen@innovate.tech",
    },
    company: "InnovateTech",
    preview: "We have some questions about API integration and custom workflows. Can we schedule a technical call?",
    timestamp: "4 hours ago",
    isRead: false,
    isImportant: true,
    isStarred: false,
    hasAttachment: true,
    unreadCount: 1,
    emailCount: 1,
    lastActivity: "4 hours ago",
    status: "active",
    tags: ["Technical", "Integration"],
    aiSuggestion: "Schedule technical call",
    hasAIDraft: false,
  },
];

