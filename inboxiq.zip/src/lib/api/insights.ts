// API service for AI Insights
import { supabase } from "@/lib/supabase";
import type { AIInsight, InsertAIInsight, UpdateAIInsight } from "@/types/database";

export const insightsApi = {
  // Get recent insights for the current user
  async getRecent(betterAuthUserId: string, limit: number = 10): Promise<AIInsight[]> {
    if (!supabase) {
      throw new Error("Supabase client not initialized");
    }

    const { data, error } = await supabase.rpc("get_recent_insights", {
      p_better_auth_id: betterAuthUserId,
      p_limit: limit,
    });

    if (error) {
      console.error("Error fetching insights:", error);
      throw new Error(`Failed to fetch insights: ${error.message}`);
    }

    return data || [];
  },

  // Get all insights
  async getAll(userId: string, type?: "daily" | "weekly" | "lead_specific" | "opportunity" | "risk"): Promise<AIInsight[]> {
    if (!supabase) {
      throw new Error("Supabase client not initialized");
    }

    let query = supabase
      .from("ai_insights")
      .select(`
        *,
        lead:leads(*)
      `)
      .eq("user_id", userId)
      .order("created_at", { ascending: false });

    if (type) {
      query = query.eq("insight_type", type);
    }

    const { data, error } = await query;

    if (error) {
      console.error("Error fetching insights:", error);
      throw new Error(`Failed to fetch insights: ${error.message}`);
    }

    return data || [];
  },

  // Create a new insight
  async create(insight: InsertAIInsight): Promise<AIInsight> {
    if (!supabase) {
      throw new Error("Supabase client not initialized");
    }

    const { data, error } = await supabase
      .from("ai_insights")
      .insert(insight)
      .select()
      .single();

    if (error) {
      console.error("Error creating insight:", error);
      throw new Error(`Failed to create insight: ${error.message}`);
    }

    return data;
  },

  // Mark insight as read
  async markAsRead(insightId: string, userId: string): Promise<AIInsight> {
    if (!supabase) {
      throw new Error("Supabase client not initialized");
    }

    const { data, error } = await supabase
      .from("ai_insights")
      .update({ is_read: true })
      .eq("id", insightId)
      .eq("user_id", userId)
      .select()
      .single();

    if (error) {
      console.error("Error marking insight as read:", error);
      throw new Error(`Failed to update insight: ${error.message}`);
    }

    return data;
  },

  // Delete an insight
  async delete(insightId: string, userId: string): Promise<void> {
    if (!supabase) {
      throw new Error("Supabase client not initialized");
    }

    const { error } = await supabase
      .from("ai_insights")
      .delete()
      .eq("id", insightId)
      .eq("user_id", userId);

    if (error) {
      console.error("Error deleting insight:", error);
      throw new Error(`Failed to delete insight: ${error.message}`);
    }
  },
};

