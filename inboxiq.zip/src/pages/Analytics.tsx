import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown,
  Mail,
  Clock,
  Users,
  Sparkles,
  Zap,
  Target,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Filter,
  Info,
  X
} from "lucide-react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { mockAnalytics } from "@/data/mockAnalyticsData";
import { toast } from "sonner";

type TimeRange = "7d" | "30d" | "90d" | "all";
type ChartType = "sent" | "replied" | "opened" | "all";

const Analytics = () => {
  const [timeRange, setTimeRange] = useState<TimeRange>("30d");
  const [selectedChartType, setSelectedChartType] = useState<ChartType>("all");
  const [hoveredBar, setHoveredBar] = useState<number | null>(null);
  const [selectedLead, setSelectedLead] = useState<string | null>(null);
  const [showTooltip, setShowTooltip] = useState(false);
  const [tooltipData, setTooltipData] = useState<{ x: number; y: number; content: string } | null>(null);
  const [expandedMetric, setExpandedMetric] = useState<string | null>(null);

  const formatNumber = (num: number) => {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + "k";
    }
    return num.toString();
  };

  const formatPercent = (num: number) => {
    return `${num > 0 ? "+" : ""}${num.toFixed(1)}%`;
  };

  const MetricCard = ({ 
    title, 
    value, 
    change, 
    trend, 
    icon: Icon,
    format = (v: number) => v.toString(),
    id
  }: {
    title: string;
    value: number;
    change: number;
    trend: "up" | "down" | "neutral";
    icon: typeof TrendingUp;
    format?: (v: number) => string;
    id?: string;
  }) => {
    const isPositive = trend === "up" && change > 0;
    const isNegative = trend === "down" || (trend === "up" && change < 0);
    const isExpanded = expandedMetric === id;

    return (
      <motion.div
        className="card-elevated p-5 cursor-pointer hover:border-accent/40 transition-all"
        onClick={() => setExpandedMetric(isExpanded ? null : id || null)}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="flex items-start justify-between mb-4">
          <motion.div
            className="p-2.5 rounded-lg bg-accent/10"
            whileHover={{ rotate: 360 }}
            transition={{ duration: 0.5 }}
          >
            <Icon className="w-5 h-5 text-accent" />
          </motion.div>
          {change !== 0 && (
            <div className={cn(
              "flex items-center gap-1 text-xs font-medium",
              isPositive && "text-status-success",
              isNegative && "text-status-risk",
              !isPositive && !isNegative && "text-muted-foreground"
            )}>
              {isPositive ? <ArrowUpRight className="w-3 h-3" /> : isNegative ? <ArrowDownRight className="w-3 h-3" /> : null}
              {formatPercent(change)}
            </div>
          )}
        </div>
        <div className="space-y-1">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <motion.p
            className="text-3xl font-bold text-foreground"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.1, type: "spring" }}
          >
            {format(value)}
          </motion.p>
        </div>
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mt-4 pt-4 border-t border-border overflow-hidden"
            >
              <div className="text-xs text-muted-foreground space-y-1">
                <p>Click to view detailed breakdown</p>
                <p className="flex items-center gap-1">
                  <Info className="w-3 h-3" />
                  Last updated: {timeRange === "7d" ? "7 days" : timeRange === "30d" ? "30 days" : timeRange === "90d" ? "90 days" : "All time"}
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  };

  const SimpleBarChart = ({ 
    data, 
    maxValue, 
    color = "accent",
    onBarHover,
    hoveredIndex
  }: { 
    data: Array<{ label: string; value: number }>; 
    maxValue: number;
    color?: string;
    onBarHover?: (index: number | null) => void;
    hoveredIndex?: number | null;
  }) => {
    return (
      <div className="flex items-end justify-between gap-2 h-32">
        {data.map((item, index) => {
          const height = (item.value / maxValue) * 100;
          const isHovered = hoveredIndex === index;
          return (
            <motion.div
              key={index}
              className="flex-1 flex flex-col items-center gap-2 cursor-pointer"
              onHoverStart={() => onBarHover?.(index)}
              onHoverEnd={() => onBarHover?.(null)}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <div className="relative w-full h-24 bg-muted rounded-t overflow-hidden group">
                <motion.div
                  className={cn(
                    "absolute bottom-0 w-full rounded-t transition-all",
                    color === "accent" && "bg-accent",
                    color === "success" && "bg-status-success",
                    color === "hot" && "bg-status-hot",
                    color === "warm" && "bg-status-warm"
                  )}
                  style={{ height: `${height}%` }}
                  animate={{
                    height: isHovered ? `${Math.min(height * 1.1, 100)}%` : `${height}%`,
                  }}
                  transition={{ duration: 0.2 }}
                />
                {isHovered && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="absolute -top-8 left-1/2 -translate-x-1/2 bg-foreground text-background px-2 py-1 rounded text-xs font-medium whitespace-nowrap z-10"
                  >
                    {item.value}
                  </motion.div>
                )}
              </div>
              <span className={cn(
                "text-xs transition-colors",
                isHovered ? "text-foreground font-medium" : "text-muted-foreground"
              )}>
                {item.label}
              </span>
              <span className={cn(
                "text-xs font-medium transition-colors",
                isHovered ? "text-foreground" : "text-foreground"
              )}>
                {item.value}
              </span>
            </motion.div>
          );
        })}
      </div>
    );
  };

  const ProgressBar = ({ value, max, label, color = "accent" }: {
    value: number;
    max: number;
    label: string;
    color?: string;
  }) => {
    const percentage = (value / max) * 100;
    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-foreground">{label}</span>
          <span className="font-medium text-foreground">{value} / {max}</span>
        </div>
        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
          <div
            className={cn(
              "h-full transition-all rounded-full",
              color === "accent" && "bg-accent",
              color === "success" && "bg-status-success",
              color === "hot" && "bg-status-hot",
              color === "warm" && "bg-status-warm",
              color === "cold" && "bg-status-cold"
            )}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    );
  };

  // Filter email performance data based on selected chart type
  const emailPerformanceData = useMemo(() => {
    if (selectedChartType === "all") {
      return mockAnalytics.emailPerformance.map(d => ({
        label: d.date,
        sent: d.sent,
        replied: d.replied,
        opened: d.opened,
      }));
    } else {
      return mockAnalytics.emailPerformance.map(d => ({
        label: d.date,
        value: d[selectedChartType],
      }));
    }
  }, [selectedChartType]);

  const maxEmailValue = Math.max(...mockAnalytics.emailPerformance.map(d => Math.max(d.sent, d.replied, d.opened)));

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-[1600px] mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
              <BarChart3 className="w-6 h-6 text-accent" />
              Analytics
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Track your email performance and lead management metrics
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 border border-border rounded-lg p-1">
              {(["7d", "30d", "90d", "all"] as TimeRange[]).map((range) => (
                <motion.div key={range} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button
                    variant={timeRange === range ? "default" : "ghost"}
                    size="sm"
                    onClick={() => {
                      setTimeRange(range);
                      toast.success(`Viewing ${range === "all" ? "all time" : range} data`);
                    }}
                    className="h-7 px-3 text-xs"
                  >
                    {range === "all" ? "All Time" : range.toUpperCase()}
                  </Button>
                </motion.div>
              ))}
            </div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={() => toast.success("Exporting analytics data...")}
              >
                <Filter className="w-4 h-4" />
                Export
              </Button>
            </motion.div>
          </div>
        </div>

        {/* Overview Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <MetricCard
            id="total-leads"
            title="Total Leads"
            value={mockAnalytics.overview.totalLeads.current}
            change={mockAnalytics.overview.totalLeads.change}
            trend={mockAnalytics.overview.totalLeads.trend}
            icon={Users}
            format={formatNumber}
          />
          <MetricCard
            id="active-conversations"
            title="Active Conversations"
            value={mockAnalytics.overview.activeConversations.current}
            change={mockAnalytics.overview.activeConversations.change}
            trend={mockAnalytics.overview.activeConversations.trend}
            icon={Mail}
          />
          <MetricCard
            id="reply-rate"
            title="Reply Rate"
            value={mockAnalytics.overview.replyRate.current}
            change={mockAnalytics.overview.replyRate.change}
            trend={mockAnalytics.overview.replyRate.trend}
            icon={Target}
            format={(v) => `${v}%`}
          />
          <MetricCard
            id="response-time"
            title="Avg Response Time"
            value={mockAnalytics.overview.avgResponseTime.current}
            change={mockAnalytics.overview.avgResponseTime.change}
            trend={mockAnalytics.overview.avgResponseTime.trend}
            icon={Clock}
            format={(v) => `${v}h`}
          />
          <MetricCard
            id="time-saved"
            title="Time Saved (AI)"
            value={mockAnalytics.overview.timeSaved.current}
            change={mockAnalytics.overview.timeSaved.change}
            trend={mockAnalytics.overview.timeSaved.trend}
            icon={Zap}
            format={(v) => `${v}h`}
          />
          <MetricCard
            id="ai-drafts"
            title="AI Drafts Used"
            value={mockAnalytics.overview.aiDraftsUsed.current}
            change={mockAnalytics.overview.aiDraftsUsed.change}
            trend={mockAnalytics.overview.aiDraftsUsed.trend}
            icon={Sparkles}
            format={formatNumber}
          />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Email Performance Chart */}
          <motion.div
            className="card-elevated p-6"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Email Performance</h3>
                <p className="text-sm text-muted-foreground">Last 7 days</p>
              </div>
              <div className="flex items-center gap-1 border border-border rounded-lg p-1">
                {(["all", "sent", "replied", "opened"] as ChartType[]).map((type) => (
                  <Button
                    key={type}
                    variant={selectedChartType === type ? "default" : "ghost"}
                    size="sm"
                    onClick={() => setSelectedChartType(type)}
                    className="h-7 px-2 text-xs capitalize"
                  >
                    {type}
                  </Button>
                ))}
              </div>
            </div>
            {selectedChartType === "all" ? (
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">Sent</span>
                  </div>
                  <SimpleBarChart
                    data={mockAnalytics.emailPerformance.map(d => ({ label: d.date, value: d.sent }))}
                    maxValue={maxEmailValue}
                    color="accent"
                    onBarHover={setHoveredBar}
                    hoveredIndex={hoveredBar}
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">Replied</span>
                  </div>
                  <SimpleBarChart
                    data={mockAnalytics.emailPerformance.map(d => ({ label: d.date, value: d.replied }))}
                    maxValue={maxEmailValue}
                    color="success"
                    onBarHover={setHoveredBar}
                    hoveredIndex={hoveredBar}
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">Opened</span>
                  </div>
                  <SimpleBarChart
                    data={mockAnalytics.emailPerformance.map(d => ({ label: d.date, value: d.opened }))}
                    maxValue={maxEmailValue}
                    color="warm"
                    onBarHover={setHoveredBar}
                    hoveredIndex={hoveredBar}
                  />
                </div>
              </div>
            ) : (
              <SimpleBarChart
                data={emailPerformanceData as Array<{ label: string; value: number }>}
                maxValue={maxEmailValue}
                color={selectedChartType === "replied" ? "success" : selectedChartType === "opened" ? "warm" : "accent"}
                onBarHover={setHoveredBar}
                hoveredIndex={hoveredBar}
              />
            )}
            <div className="flex items-center gap-4 mt-4 pt-4 border-t border-border">
              <button
                className={cn(
                  "flex items-center gap-2 px-2 py-1 rounded transition-colors",
                  selectedChartType === "sent" || selectedChartType === "all" ? "bg-accent/10" : "hover:bg-muted"
                )}
                onClick={() => setSelectedChartType("sent")}
              >
                <div className="w-3 h-3 rounded-full bg-accent" />
                <span className="text-xs text-muted-foreground">Sent</span>
              </button>
              <button
                className={cn(
                  "flex items-center gap-2 px-2 py-1 rounded transition-colors",
                  selectedChartType === "replied" || selectedChartType === "all" ? "bg-status-success/10" : "hover:bg-muted"
                )}
                onClick={() => setSelectedChartType("replied")}
              >
                <div className="w-3 h-3 rounded-full bg-status-success" />
                <span className="text-xs text-muted-foreground">Replied</span>
              </button>
              <button
                className={cn(
                  "flex items-center gap-2 px-2 py-1 rounded transition-colors",
                  selectedChartType === "opened" || selectedChartType === "all" ? "bg-status-warm/10" : "hover:bg-muted"
                )}
                onClick={() => setSelectedChartType("opened")}
              >
                <div className="w-3 h-3 rounded-full bg-status-warm" />
                <span className="text-xs text-muted-foreground">Opened</span>
              </button>
            </div>
          </motion.div>

          {/* Lead Distribution */}
          <div className="card-elevated p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Lead Distribution</h3>
                <p className="text-sm text-muted-foreground">By status</p>
              </div>
            </div>
            <div className="space-y-4">
              <ProgressBar
                value={mockAnalytics.leadDistribution.hot}
                max={mockAnalytics.leadDistribution.hot + mockAnalytics.leadDistribution.warm + mockAnalytics.leadDistribution.cold}
                label="Hot Leads"
                color="hot"
              />
              <ProgressBar
                value={mockAnalytics.leadDistribution.warm}
                max={mockAnalytics.leadDistribution.hot + mockAnalytics.leadDistribution.warm + mockAnalytics.leadDistribution.cold}
                label="Warm Leads"
                color="warm"
              />
              <ProgressBar
                value={mockAnalytics.leadDistribution.cold}
                max={mockAnalytics.leadDistribution.hot + mockAnalytics.leadDistribution.warm + mockAnalytics.leadDistribution.cold}
                label="Cold Leads"
                color="cold"
              />
            </div>
            <div className="mt-6 pt-6 border-t border-border grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-status-hot">{mockAnalytics.leadDistribution.hot}</div>
                <div className="text-xs text-muted-foreground">Hot</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-status-warm">{mockAnalytics.leadDistribution.warm}</div>
                <div className="text-xs text-muted-foreground">Warm</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-status-cold">{mockAnalytics.leadDistribution.cold}</div>
                <div className="text-xs text-muted-foreground">Cold</div>
              </div>
            </div>
          </div>
        </div>

        {/* Trends Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Reply Rate Trend */}
          <div className="card-elevated p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Reply Rate Trend</h3>
                <p className="text-sm text-muted-foreground">Last 4 weeks</p>
              </div>
            </div>
            <SimpleBarChart
              data={mockAnalytics.replyRateTrend.map(d => ({ label: d.date, value: d.value }))}
              maxValue={100}
              color="success"
              onBarHover={setHoveredBar}
              hoveredIndex={hoveredBar}
            />
            <div className="mt-4 pt-4 border-t border-border">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Current Rate</span>
                <span className="text-2xl font-bold text-status-success">{mockAnalytics.overview.replyRate.current}%</span>
              </div>
            </div>
          </div>

          {/* Response Time Trend */}
          <div className="card-elevated p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Response Time Trend</h3>
                <p className="text-sm text-muted-foreground">Last 4 weeks (hours)</p>
              </div>
            </div>
            <SimpleBarChart
              data={mockAnalytics.responseTimeTrend.map(d => ({ label: d.date, value: d.value }))}
              maxValue={5}
              color="warm"
              onBarHover={setHoveredBar}
              hoveredIndex={hoveredBar}
            />
            <div className="mt-4 pt-4 border-t border-border">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Average Time</span>
                <span className="text-2xl font-bold text-foreground">{mockAnalytics.overview.avgResponseTime.current}h</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* AI Usage Stats */}
          <div className="card-elevated p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-accent" />
                  AI Usage Statistics
                </h3>
                <p className="text-sm text-muted-foreground">Performance metrics</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                <span className="text-sm text-foreground">Drafts Generated</span>
                <span className="text-lg font-bold text-foreground">{mockAnalytics.aiUsage.draftsGenerated}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                <span className="text-sm text-foreground">Drafts Sent</span>
                <span className="text-lg font-bold text-foreground">{mockAnalytics.aiUsage.draftsSent}</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                <span className="text-sm text-foreground">Adoption Rate</span>
                <span className="text-lg font-bold text-status-success">{mockAnalytics.aiUsage.adoptionRate}%</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                <span className="text-sm text-foreground">Avg Confidence</span>
                <span className="text-lg font-bold text-accent">{mockAnalytics.aiUsage.avgConfidence}%</span>
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg bg-accent/10 border border-accent/20">
                <span className="text-sm text-foreground font-medium">Time Saved</span>
                <span className="text-lg font-bold text-accent">{mockAnalytics.aiUsage.timeSaved}h</span>
              </div>
            </div>
          </div>

          {/* Conversion Funnel */}
          <div className="card-elevated p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-lg font-semibold text-foreground">Conversion Funnel</h3>
                <p className="text-sm text-muted-foreground">Lead to close</p>
              </div>
            </div>
            <div className="space-y-4">
              <ProgressBar
                value={mockAnalytics.conversionFunnel.leads}
                max={mockAnalytics.conversionFunnel.leads}
                label="Leads"
                color="accent"
              />
              <ProgressBar
                value={mockAnalytics.conversionFunnel.contacted}
                max={mockAnalytics.conversionFunnel.leads}
                label="Contacted"
                color="warm"
              />
              <ProgressBar
                value={mockAnalytics.conversionFunnel.replied}
                max={mockAnalytics.conversionFunnel.leads}
                label="Replied"
                color="success"
              />
              <ProgressBar
                value={mockAnalytics.conversionFunnel.meetings}
                max={mockAnalytics.conversionFunnel.leads}
                label="Meetings Scheduled"
                color="hot"
              />
              <ProgressBar
                value={mockAnalytics.conversionFunnel.closed}
                max={mockAnalytics.conversionFunnel.leads}
                label="Closed Deals"
                color="accent"
              />
            </div>
            <div className="mt-6 pt-6 border-t border-border">
              <div className="text-center">
                <div className="text-3xl font-bold text-foreground">
                  {((mockAnalytics.conversionFunnel.closed / mockAnalytics.conversionFunnel.leads) * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-muted-foreground">Conversion Rate</div>
              </div>
            </div>
          </div>
        </div>

        {/* Top Performing Leads */}
        <div className="card-elevated p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-semibold text-foreground">Top Performing Leads</h3>
              <p className="text-sm text-muted-foreground">By engagement and value</p>
            </div>
          </div>
          <div className="space-y-3">
            {mockAnalytics.topLeads.map((lead, index) => {
              const statusColor = {
                hot: "text-status-hot border-status-hot bg-status-hot-bg",
                warm: "text-status-warm border-status-warm bg-status-warm-bg",
                cold: "text-status-cold border-status-cold bg-status-cold-bg",
              }[lead.status];
              const isSelected = selectedLead === lead.company;

              return (
                <motion.div
                  key={index}
                  className={cn(
                    "flex items-center justify-between p-4 rounded-lg bg-muted/30 transition-colors cursor-pointer",
                    isSelected ? "bg-accent/10 border-2 border-accent" : "hover:bg-muted/50 border-2 border-transparent"
                  )}
                  onClick={() => {
                    setSelectedLead(isSelected ? null : lead.company);
                    toast.success(isSelected ? "Lead deselected" : `Viewing ${lead.company} details`);
                  }}
                  whileHover={{ scale: 1.02, x: 4 }}
                  whileTap={{ scale: 0.98 }}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="flex items-center gap-4 flex-1">
                    <motion.div
                      className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-violet-500 flex items-center justify-center text-white font-semibold text-sm"
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.5 }}
                    >
                      {lead.company.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()}
                    </motion.div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-foreground truncate">{lead.company}</div>
                      <div className="text-sm text-muted-foreground">{lead.replies} replies</div>
                    </div>
                    <div className={cn(
                      "inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border",
                      statusColor
                    )}>
                      <span className="capitalize">{lead.status}</span>
                    </div>
                  </div>
                  <div className="text-right ml-4">
                    <div className="text-lg font-bold text-foreground">${formatNumber(lead.value)}</div>
                    <div className="text-xs text-muted-foreground">Est. Value</div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Analytics;

