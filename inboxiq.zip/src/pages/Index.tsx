import { useState } from "react";
import { Flame, Bell, FileEdit, AlertTriangle, TrendingUp, Clock, Zap } from "lucide-react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import StatusCard from "@/components/dashboard/StatusCard";
import AIInsightPanel from "@/components/dashboard/AIInsightPanel";
import LeadPipeline from "@/components/dashboard/LeadPipeline";
import ActionQueue from "@/components/dashboard/ActionQueue";
import EmailPreviewPanel from "@/components/dashboard/EmailPreviewPanel";
import PerformanceSnapshot from "@/components/dashboard/PerformanceSnapshot";
import { mockLeads, mockActions, mockInsight, mockPerformanceMetrics, mockEmailDraft } from "@/data/mockData";

// Note: User name is Debayan Lahiry

const Index = () => {
  const [emailPanelOpen, setEmailPanelOpen] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState<typeof mockEmailDraft | null>(null);

  const handleLeadClick = (lead: typeof mockLeads[0]) => {
    if (lead.hasAIDraft) {
      setSelectedEmail({
        to: lead.email,
        subject: `Re: ${lead.company} - Follow Up`,
        company: lead.company,
        reason: lead.aiSuggestion || "AI suggested follow-up based on conversation history",
        draft: mockEmailDraft.draft,
      });
      setEmailPanelOpen(true);
    }
  };

  const handleActionReviewSend = (action: typeof mockActions[0]) => {
    setSelectedEmail({
      to: mockLeads.find(l => l.company === action.company)?.email || "contact@company.com",
      subject: action.subject,
      company: action.company,
      reason: action.reason,
      draft: mockEmailDraft.draft,
    });
    setEmailPanelOpen(true);
  };

  const performanceMetricsWithIcons = [
    { ...mockPerformanceMetrics[0], icon: TrendingUp },
    { ...mockPerformanceMetrics[1], icon: Clock },
    { ...mockPerformanceMetrics[2], icon: Zap },
  ];

  const hotLeadsCount = mockLeads.filter(l => l.status === "hot").length;
  const needsFollowUpCount = mockLeads.filter(l => l.daysSinceContact >= 3).length;
  const draftsReadyCount = mockLeads.filter(l => l.hasAIDraft).length;
  const atRiskCount = mockLeads.filter(l => l.daysSinceContact >= 5).length;

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-[1600px] mx-auto">
        {/* Status Cards */}
        <div className="grid grid-cols-4 gap-4">
          <StatusCard
            title="Hot Leads"
            value={hotLeadsCount}
            change={{ value: 25, trend: "up" }}
            icon={Flame}
            variant="hot"
            subtitle="Ready to close"
          />
          <StatusCard
            title="Needs Follow-Up"
            value={needsFollowUpCount}
            icon={Bell}
            variant="warm"
            subtitle="Due today"
          />
          <StatusCard
            title="AI Drafts Ready"
            value={draftsReadyCount}
            change={{ value: 3, trend: "up" }}
            icon={FileEdit}
            variant="default"
            subtitle="Awaiting review"
          />
          <StatusCard
            title="Deals at Risk"
            value={atRiskCount}
            icon={AlertTriangle}
            variant="risk"
            subtitle="No reply 5+ days"
          />
        </div>

        {/* AI Insight Panel */}
        <AIInsightPanel 
          insight={mockInsight.text}
          highlights={mockInsight.highlights}
        />

        {/* Performance Metrics - Full Width */}
        <PerformanceSnapshot metrics={performanceMetricsWithIcons} />

        {/* Main content grid */}
        <div className="grid grid-cols-12 gap-6">
          {/* Lead Pipeline - Takes 8 columns */}
          <div className="col-span-8">
            <LeadPipeline 
              leads={mockLeads}
              onLeadClick={handleLeadClick}
            />
          </div>

          {/* Right column - Action Queue */}
          <div className="col-span-4">
            <ActionQueue 
              actions={mockActions}
              onReviewSend={handleActionReviewSend}
            />
          </div>
        </div>
      </div>

      {/* Email Preview Panel (Slide-over) */}
      <EmailPreviewPanel
        isOpen={emailPanelOpen}
        onClose={() => setEmailPanelOpen(false)}
        email={selectedEmail}
      />

      {/* Overlay when panel is open */}
      {emailPanelOpen && (
        <div 
          className="fixed inset-0 bg-foreground/10 z-40"
          onClick={() => setEmailPanelOpen(false)}
        />
      )}
    </DashboardLayout>
  );
};

export default Index;
